/*******************************************************************************
 * resolucao.h                                                                 *
 * Propósito: Enuncia a principal função do TAD                                *
 *                                                                             *
 * @author Jéssica Taís C. Rodrigues                                           *
 * @version 1.0 22/04/2017                                                     *
 ******************************************************************************/

#ifndef _RESOLUCAO_H_
#define _RESOLUCAO_H_

void resolve(char *expressao, int resultado);

#endif